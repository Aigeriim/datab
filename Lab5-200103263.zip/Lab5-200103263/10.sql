SELECT count(DISTINCT c_custkey) FROM(

SELECT customer.c_custkey, count(DISTINCT o_orderkey) FROM orders INNER JOIN lineitem 
ON orders.o_orderkey = lineitem.l_orderkey
INNER JOIN customer ON orders.o_custkey = customer.c_custkey
INNER JOIN supplier ON lineitem.l_suppkey = supplier.s_suppkey
INNER JOIN nation ON nation.n_nationkey = supplier.s_nationkey
INNER JOIN region ON nation.n_regionkey=region.r_regionkey
GROUP BY c_custkey

EXCEPT 

SELECT customer.c_custkey, count(DISTINCT o_orderkey) FROM orders INNER JOIN lineitem 
ON orders.o_orderkey = lineitem.l_orderkey
INNER JOIN customer ON  customer.c_custkey=orders.o_custkey
INNER JOIN supplier ON lineitem.l_suppkey = supplier.s_suppkey
INNER JOIN nation ON nation.n_nationkey = supplier.s_nationkey
INNER JOIN region ON nation.n_regionkey=region.r_regionkey  
WHERE region.r_name = "ASIA"
GROUP BY c_custkey

);