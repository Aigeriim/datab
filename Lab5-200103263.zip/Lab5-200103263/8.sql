SELECT COUNT(*) as customers
FROM customer
        INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey
        INNER JOIN region ON region.r_regionkey = nation.n_regionkey
        AND region.r_name = "EUROPE"