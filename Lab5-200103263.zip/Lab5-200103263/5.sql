SELECT orders.o_orderpriority as order_priority,
    COUNT(*) as part_nbr
FROM orders
    INNER JOIN lineitem ON orders.o_orderkey = lineitem.l_orderkey
    AND strftime('%Y', orders.o_orderdate) = '1994'
    AND lineitem.l_receiptdate < lineitem.l_commitdate
    INNER JOIN part ON part.p_partkey = lineitem.l_partkey
GROUP BY order_priority
ORDER BY part_nbr DESC;