SELECT nation.n_name as country,
        orders.o_orderstatus as order_status,
        COUNT(*) as order_nbr
FROM orders
        INNER JOIN (
                customer
                INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey
                INNER JOIN region ON region.r_regionkey = nation.n_regionkey
                AND region.r_name = "MIDDLE EAST"
        ) ON orders.o_custkey = customer.c_custkey
GROUP BY nation.n_name,
        orders.o_orderstatus;