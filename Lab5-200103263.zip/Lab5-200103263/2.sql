SELECT supplier.s_name as country,
    orders.o_orderpriority as order_priority,
    COUNT(*) as order_nbr
FROM supplier
    INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey
    INNER JOIN region ON region.r_regionkey = nation.n_regionkey
    AND region.r_name = "ASIA"
    INNER JOIN lineitem ON supplier.s_suppkey = lineitem.l_suppkey
    INNER JOIN orders ON orders.o_orderkey = lineitem.l_orderkey
GROUP BY orders.o_orderpriority,
    supplier.s_name
ORDER BY orders.o_orderpriority,
    order_nbr;