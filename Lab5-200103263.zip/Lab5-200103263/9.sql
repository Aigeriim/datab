SELECT DISTINCT nation.n_name as countries
FROM supplier
    INNER JOIN customer ON supplier.s_nationkey = customer.c_nationkey
    INNER JOIN nation ON nation.n_nationkey = supplier.s_nationkey
    INNER JOIN region ON region.r_regionkey = nation.n_regionkey
WHERE region.r_name = "EUROPE"
ORDER BY countries;