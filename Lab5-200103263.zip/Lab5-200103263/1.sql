SELECT supplier.s_name as supplier,
    COUNT(*) as parts_nbr
FROM supplier
    INNER JOIN partsupp ON supplier.s_suppkey = partsupp.p_suppkey
    INNER JOIN part ON part.p_partkey = partsupp.ps_partkey
    AND part.p_size < 10
    INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey
    AND nation.n_name = "INDIA"
GROUP BY supplier.s_name
ORDER BY supplier.s_name;