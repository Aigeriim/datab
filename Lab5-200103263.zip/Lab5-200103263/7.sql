SELECT region1,
    region2,
    ROUND(SUM(o_totalprice)) as total_price
FROM(
SELECT supplier.s_suppkey,
    region.r_name as region2,
    orders.o_custkey,
    orders.o_totalprice
FROM supplier
    INNER JOIN nation ON nation.n_nationkey = supplier.s_nationkey
    INNER JOIN region ON region.r_regionkey = nation.n_regionkey
    INNER JOIN lineitem ON lineitem.l_suppkey = supplier.s_suppkey
    INNER JOIN orders ON lineitem.l_orderkey = orders.o_orderkey)
    INNER JOIN
(SELECT customer.c_custkey,
    region.r_name as region1
FROM customer
    INNER JOIN nation ON nation.n_nationkey = customer.c_nationkey
    INNER JOIN region ON region.r_regionkey = nation.n_regionkey) ON c_custkey = o_custkey
GROUP BY region2,
    region1
HAVING region2 <> region1
ORDER BY region2,
    region1;