SELECT COUNT(DISTINCT orders.o_orderkey) as orders_nbr
FROM (
        supplier
        INNER JOIN lineitem ON supplier.s_suppkey = lineitem.l_suppkey
        AND supplier.s_acctbal < 0
    )
    INNER JOIN orders ON orders.o_orderkey = lineitem.l_orderkey
    INNER JOIN customer ON customer.c_custkey = orders.o_custkey
    AND customer.c_acctbal < 0;