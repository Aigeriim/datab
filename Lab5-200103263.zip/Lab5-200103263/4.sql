SELECT COUNT(DISTINCT orders.o_clerk) as order_clerks
FROM nation
    INNER JOIN supplier ON supplier.s_nationkey = nation.n_nationkey
    AND nation.n_name = "RUSSIA"
    INNER JOIN lineitem ON supplier.s_suppkey = lineitem.l_suppkey
    INNER JOIN orders ON orders.o_orderkey = lineitem.l_orderkey